<?php

function Conect()
{
    # code...

    $echo = mysqli_connect("localhost","ruta-user","t*P{Gxy=gf?0","ruta-inmobiliaria");

    return $echo;
}

?>
